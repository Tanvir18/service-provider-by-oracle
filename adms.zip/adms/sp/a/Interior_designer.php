<?php
  include('config.php');
	session_start();

?>

<html><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://pingendo.github.io/pingendo-bootstrap/themes/default/bootstrap.css" rel="stylesheet" type="text/css">
  </head><body>
    <div class="navbar navbar-default navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php"><span>Service Provider</span></a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-ex-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li class="active">
              <a href="index.php">Home</a>
            </li>
            <li class="active">
              <a href="logout.php">Sign out <?php if(isset($_SESSION['email'])){ echo $_SESSION['email'];} ?></a>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Sign up <i class="fa fa-caret-down"></i></a>
              <ul class="dropdown-menu" role="menu">
                <li id="signup">
                  <a href="Signup.php">as User</a>
                </li>
                <li>
                  <a href="host_sign.php">as Host</a>
                </li>
                
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="col-md-2">
      <div class="btn-group btn-group-lg">
        <a class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Catagory<br><span class="fa fa-caret-down"></span></a>
        <ul class="dropdown-menu" role="menu">
          <li>
            <a href="cook.php">Cook</a>
            <a href="Electrician.php">Electrician</a>
            <a href="Interior_designer.php">Interior Designer</a>
            <a href="Photographer.php">Photographer</a>
          </li>
        </ul>
      </div>
    </div>


    <div class="col-md-10">
      <div class="section">
        <div class="container">
          <div class="row">

<?php

          $query = "SELECT * FROM host_user WHERE category='interior_designer' ";
  $result_query = mysqli_query($con, $query);
   
  
      while($row = mysqli_fetch_assoc($result_query)){
      
       $interior_designer_id = $row['id']; 
       $name=$row['name'];
       $email=$row['email'];
       $contact=$row['contact'];
       $address=$row['address'];
       $national_id  =  $row['national_id'];
       $personal_information  =  $row['personal_information'];
       $skill  =  $row['skill'];
       $experience  =$row['experience'];
       $rate  =$row['rate'];
       $fileToUpload  = $row['photo'];
       
       $category  =  $row['category']; 

?>





            <div class="col-md-3">
              <img src="image\person cook.jpg" class="img-responsive">
              <h2><?php 
               echo "<a href='interior_designer_profile.php?interior_designer_id={$interior_designer_id}'> {$name} </a>";
               ?>
              </h2>
              <p>interior Designer</p>
            </div>

           
            

            <a href="#">
                  </a>

                   <?php 

              }

            ?>
            
      <a href="#">
          </a>
    </div>
    </div>
    </div>
    </div>

  

</body></html>