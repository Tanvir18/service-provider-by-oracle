<?php

odbc_close($con);
?>