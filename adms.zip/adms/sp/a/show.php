<?php

ob_start();
session_start();
if($_SESSION['email'] !='admin')
{
	header('location:loginpanel.html');
}


?>
 



<html>
<head>
<title>registration</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Bootstrap 101 Template</title>
  
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet"><!--[FONT AWESOME]-->
    <link href="css/responsive.css" rel="stylesheet">
</head>
<body>
  
  <?php
    
   include('config.php');
  
  ?>
   
   <div class="container">
     <div class="row ">
	    <div class="col-md-offset-4 col-sm-offset-4  ">
		    <h2>user information</h2>
			<table border="1" >
			     <tr>
				   <th>Sl</th>
				   <th>Name</th>
				   <th>User Name</th>
				   <th>Email</th>
				   <th>Password</th>
				   <th>Address</th>
				</tr>
				<?php
				   $i=0;
				   $sql = "SELECT * FROM user";
				  $result= mysqli_query($con,$sql);


                 while($row =mysqli_fetch_assoc($result)) { 
                 $i++
				 ?>
				 <tr>
				   <td><?php  echo $i?></td>
				   <td><?php  echo $row["name"];?></td>
				   <td><?php  echo $row["email"];?></td>
				   <td><?php  echo $row["password"];?></td>
				    <td><?php  echo $row["contact"];?></td>
				   <td><?php  echo $row["address"];?></td>
				</tr>   <?php      
				}
    
               ?>
				
				
			</table>
			
            <a href="logout.php">Log-out</a>
		</div>
	 </div>
  </div>
  
</body>
</html>