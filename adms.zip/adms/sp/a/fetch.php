<?php
if(!empty($_GET['q']))
{
	include 'config.php';
	$q=$_GET['q'];
	$query="select name,id from host_user where name like '%$q%'";
	$result=odbc_exec($con,$query);
	while ($output=odbc_fetch_array($result)) 
	{
		echo "<a href='cook_profile.php?cook_id=$output[ID]' target='_blank'>$output[NAME]</a>";
		//echo $output['ID'],'-', $output['NAME'];
	}
}
?>