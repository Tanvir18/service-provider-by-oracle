<html>
<head>
<title>user registration</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Bootstrap 101 Template</title>
  
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet"><!--[FONT AWESOME]-->
    <link href="css/responsive.css" rel="stylesheet">
</head>
<body>
  
  <?php
	session_start();
     include('config.php');
     if(isset($_POST['registrationform'])){
		 try{
		 	 $id=$_POST['u_seq.nextval'];
			 $name=$_POST['name'];
			 $email=$_POST['email'];
			 $password=$_POST['password'];
			 $confirm_password=$_POST['confirm_password'];
			 $contact=$_POST['contact'];
			 $address=$_POST['address'];
			 
			 if(empty($name))
			 {
			   throw new Exception ("Name error:name field cann't be empty ")	; 
			 }
			 
			 if(empty($email))
			 {
			   throw new Exception ("Email error:email field cann't be empty")	; 
			 }
			 else{
				 $c1=substr_count($email,'@');
				 $c2=substr_count($email,'.');
				 if(($c1!==1)||($c2!==1))
				 {
				   throw new Exception ("Email error: (@/.)cann't be use more than one ")	; 
				 }
				 else{
					 $len=strlen($email);
					 $p1=strpos($email,'@');
					 if(($p1==0)||($p1==$len-1)){
						throw new Exception ("Email error: (@)cann't be use first or last position ")	; 
					 }
					 else{
						$p2=strpos($email,'.'); 
						if(($p2==0)||($p2==$len-1)){
						  throw new Exception ("Email error: (@)cann't be use first or last position ")	; 
						   }
							else{
								if($p1>$p2)
								{
								  throw new Exception ("Email error: (.)cann't be use before(@) ")	; 	
								}
								else{
									if($p2-$p1==1)
									{
									  throw new Exception ("Email error: need some charecter beetween(.)-(@)")	;	
									}
								}
							}
						}
					 }
				 }
				 
			/* 
			 if(empty($password))
			 {
			   throw new Exception ("Password error:password field cann't be empty ")	; 
			 }
			 if(empty($confirm_password))
			 {
			   throw new Exception ("Password error:confirm password field cann't be empty ")	; 
			 }
			 else{
				 if($password!==$confirm_password){
					throw new Exception ("Password error:password does not match ");	 
				 }
			 }
			 if(empty($contact))
			 {
			   throw new Exception ("conatct error:conatct field cann't be empty ")	; 
			 }
			 if(empty($address))
			 {
			   throw new Exception ("Address error:Address field cann't be empty")	; 
			 }*/
			 $result = "INSERT INTO users(id,name,email,password,contact,address) VALUES (u_seq.nextval,'$_POST[name]','$_POST[email]','$_POST[password]','$_POST[contact]','$_POST[address]')";

			 //$result = "INSERT INTO users(id,name,email,password,contact,address) VALUES (14,'NAME','EMAIL','PASSWORD','CONTACT','ADDRESS')";

             odbc_exec($con,$result);
             header('location:signin.php');
			
			 
 
		 }
		 catch(Exception $e){
			
			$error_message=$e->getMessage();
		 }
	 }
   ?>
   
   
    <?php
		if(isset($error_message))
		{
			
			echo '<script language="javascript">';
			echo 'alert("'. $error_message.'")';
			echo '</script>';
			
		}

 ?>
  
  
  
  <div class="container">
     <div class="row ">
	    <div class="col-md-offset-4 col-sm-offset-4  ">
		    <h2>User Registration</h2>
		   <form action="" method="POST">
		       <table>
			      <tr>
				     <td>Name</td>
					  <td><input type="text" name="name"></td>
				  </tr>
				  
				   <tr>
				     <td>Email</td>
					  <td><input type="text" name="email"></td>
				  </tr>
				   <tr>
				     <td>Password</td>
					  <td><input type="password" name="password"></td>
				  </tr>
				   <tr>
				     <td>Confirm Password</td>
					  <td><input type="password" name="confirm_password"></td>
				  </tr>
				   <tr>
				     <td>Contact</td>
					  <td><input type="text" name="contact"></td>
				  </tr>
				   <tr>
				     <td>Address</td>
					  <td><input type="text" name="address"></td>
				  </tr>
				   <tr>
					  <td ><input type="submit" value="submit" name="registrationform" ></td>
					<td><a href="signin.php"> Sign in</a></td>
				  </tr>
				 
				  
				  <li class="">
              <a href="index.php">Home</a>
            </li>
				  
		       </table>
            </form>
		</div>
	 </div>
  </div>
</body>
</html>