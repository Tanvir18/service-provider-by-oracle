<?php

$con = $con = odbc_connect('xe','system','system');
if (!$con) {
		die ('Error');
	}
?>