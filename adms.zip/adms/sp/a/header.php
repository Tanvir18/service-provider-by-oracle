<?php 
	session_start();

?>



<html><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://pingendo.github.io/pingendo-bootstrap/themes/default/bootstrap.css" rel="stylesheet" type="text/css">
  </head>
  <body>


      <script>
      $(document).ready(function(e){
        $("#Search").keyup(function(){
          $("#here").show();
          var x= $(this).val();
          $.ajax(
          {
              type:'GET',
              url:'fetch.php',
              data:'q='+x,
              success:function(data)
              {
                $("#here").html(data);
              }
          });
        });
      });
    
  </script>
  
  <style type="text/css">
    input
    {
      width: 400px;
      font-size: 24px;
    }
    #here
    {
      width: 400px;
      height: 300px;
      border: .5px solid grey;
      display: none;
    }

    #here a
    {
      display: block;
      width: 98%;
      padding: 1%;
      font-size: 20px;
      border-bottom: .5px solid grey;
    }
  </style>






    <div class="navbar navbar-default navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php"><span>Service Provider</span></a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-ex-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li class="">
              <a href="index.php">Home</a>
            </li>
             <li class="">
              <a href="logout.php"><?php if(isset($_SESSION['email'])){ echo "Sign Out ";} else echo "Sign In ";?><?php 
                if(isset($_SESSION['email'])) {
                  echo $_SESSION['email'];
                  
                  } 
              ?>

                
              </a>
            </li>
            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Sign up <i class="fa fa-caret-down"></i></a>
              <ul class="dropdown-menu" role="menu">
                <li id="signup">
                  <a href="Signup.php">as User</a>
                </li>
                <li>
                  <a href="host_sing.php">as Host</a>
                </li>
                
              </ul>
            </li>

            <li class="">
              <a href="notification.php">Notification</a>
            </li>


            </li>
              <li class="">
                <a href="user_profile.php">Profile</a>
              </li>


            <li class="active">
              <a href="contract-us.php">Contact Us</a>
            </li>
          </ul>
        </div>
      </div>
    </div>