	<?php
		if($_SERVER['REQUEST_METHOD']=="POST")
		{
			$self=$_SERVER["PHP_SELF"];
			if(isset($_POST['submit']))
			{
				if(isset($_POST['room_no']) and isset($_POST['nod']) and isset($_POST['advance']))
				{
					if(trim($_POST['room_no'])=="")
					{
						echo "Room No Required";
						//echo "<script>window.alert('Room No Can't Emptsy');</script>";
						die();
						//header("location:$self");
					}
					isRoomValid();
					if(trim($_POST['nod'])=="")
					{
						echo "No of days Required";
						//echo "<script>window.alert('Number Of Day Can't Empty');</script>";
						die();
						//header("location:$self");
						//die();s
					}
					if(trim($_POST['day'])=="" || trim($_POST['month'])=="" || trim($_POST['year'])=="")
					{
						echo "Invalid Booking Date";
						//echo "<script>window.alert('Date Field is Empty');</script>";
						die();
						//header("location:$self");
					}
					if(trim($_POST['advance'])=="")
					{
						$_POST['advance']=0;
					}

					insertDB();


					//echo "<br>LETS GO";
				}
				//include('../db/mysqlcon.php');
				//$query="SELECT * FROM room WHERE room_no=''"
				//echo "SUBMIT";

			}
			else
			{
				
				header("location:$self");
				//die();
			}
			//echo "<pre>";
			//var_dump($_POST);

			//if()
			//echo "POSTED";
		}
		else
		{

			/*if(isset($_REQUEST['search_room']))
			{
				$key = $_REQUEST['search_room'];
				if(!empty($key))
				{
					echo "TEST";
					//ajaxSearch();
				}
				else
				{
					echo "EMPTY KEY";
				}
			}*/
			
		}
		function isRoomValid()
		{
			include('../db/mysqlcon.php');
			$query="SELECT room_no FROM room WHERE room_no='".$_POST['room_no']."' AND room_condition='free'";
			$result=mysqli_query($con,$query);
			$rowCount=mysqli_num_rows($result);
			if($rowCount>0)
			{
				//echo "Room Is Available";
			}
			else
			{
				echo "<script>window.alert('Room Unavaiable');</script>";
				die();
			}
			mysqli_close($con);
		}
		function insertDB()
		{
			session_start();

			$userid=$_SESSION['login_user']['admin_id'];
			//echo $userid."<br>";
			//var_dump($userid);

			include('../db/mysqlcon.php');
			$roomNo=$_POST['room_no'];
			$nod=$_POST['nod'];
			$advance=$_POST['advance'];
			$day=$_POST['day'];
			$month=$_POST['month'];
			$year=$_POST['year'];
			$date=$day."-".$month."-".$year;
			$today=date("d-m-Y");
			if($date==$today)
			{
				echo "Booking Today<br>";
			}
			//echo $date."<br>";
			//echo $advance;
			$query="UPDATE room_reservation SET booking_date='".$date."' , no_of_days='".$nod."' , room_no='".$roomNo."' , advance='".$advance."' WHERE customer_id='".$userid."' ";
			$result=mysqli_query($con,$query);
			//$rowCount=mysqli_num_rows($result);
			if($result)
			{
				$query="UPDATE room SET room_condition='booked' WHERE room_no='".$roomNo."'";
				$result=mysqli_query($con,$query);
				if($result)
				{
					echo "UPDATED";
				}

				//echo "Updated <br>";
				
				//echo $today;
			}
			else
			{
				echo "Update Error";
			}
			mysqli_close($con);
		}
	?>
 




 <html>
  <form method="post">
 <head><style>
             body {background-color: powderblue;}
			 
			 </style></head>
 
 <body>
 <input onclick="location.href='main.php';" type="button" name="back" style="font-size:23px; color:grey; font-weight:500; height:35px;" value="Back"><br /><br />
  
<table border="1" style="width:60%" align="Right">
			<tr  >
				<td align="center" colspan="10">
				<h1> Room Details </h1>
				</td>
			</tr>
			
			<tr >
				<td width="10%" align="center"> <h3>Room no 	<h3></td>			
				<td width="10%" align="center"> <h3> Room Type	<h3></td>
				<td width="10%" align="center"> <h3> Capacity	<h3></td>
				<td width="10%" align="center"> <h3> Room Charge<h3></td>
				<td width="10%" align="center"> <h3> Room Condition	<h3></td>
				<?php
			include('show-available-room.php');
			?>
			</tr>	
			</table>

				
			
	<table border="0" style="width:20%" align="center">
	
	<tr>
	            <td  width="60%" >
			
				 Room no<br />
                    <input type="text" name="room_no" id="room_no" style="font-size: 16pt" size="20" onkeyup="searchRoom()" >
					<!--<span id="show"></span>-->
					<select id="show">
						<!--<option id="1" onclick="setText()">101</option>-->
					</select>
                   <br>
				 No of days <br />
                    <input type="text" name="nod" style="font-size: 16pt" size="20"><br />	
				  <br />
                    <input type="hidden" name="advance" style="font-size: 16pt" size="20"><br /><br/>

                    <div align="center" style="font-size:23px;"></div></td></tr>	
				<tr>

					<td width="10" align="center">
				Booking Date<br>
						<input size="3" type="text" name="day" placeholder="27"/>
						<input size="3" type="text" name="month" placeholder="12"/>
						<input size="5" type="text" name="year" placeholder="2016" />
					</td>
				</tr>
				<div align="center" style="font-size:23px;">
				<tr>
					<td width="10" align="center">
					<input type="submit" name="submit" value="confirm" style="font-size=20px font-weight:500; height:35px; color:green;">
					<input type="submit" name="cancel" value="cancel" style="font-size=20px font-weight:500; height:35px; color:red;">
					</td>
				</tr>
				
				<!--<div align="center" style="font-size:23px;">	
				<input type="submit" name="submit" value="confirm" style="font-size=20px font-weight:500; height:35px; color:green;">
                <div align="center" style="font-size:23px;">
				<input type="submit" name="cancel" value="cancel" style="font-size=20px font-weight:500; height:35px; color:red;"><br/><br/>-->

				

		
	</tr>					
	</table>
	</body>
<script>
    function searchRoom() {  
    	removeDropDown();      
        var txtSearchKey = document.getElementsByName("room_no")[0];

        //alert(txtSearchKey.value);

        var req = new XMLHttpRequest();
        /*0*/
        req.open("GET", "ajax/ajax-room_no.php?search_key=" + txtSearchKey.value, true);
        /*1*/
        req.onreadystatechange = function () 
        {
            if (req.readyState == 4) {
                var span = document.getElementById("show");
                var names = req.responseText.split(",");
                for (var i=0;i<names.length-1;i++) 
                {
                	span.innerHTML+='<option id='+i+' onclick="setText('+i+')" >'+names[i]+'</option>';
                    //span.innerHTML += "</br>" + names[i];
                }
                //span.innerHTML = "</br>" + names[1] + "</br>" + names[2] + "</br>" + names[3];

            }
        }
        req.send();

        /*2*/
        /*3*/
        /*4*/        
    }
    function removeDropDown()
    {
    	var selected = document.getElementById("show");
    	for (var index in selected) 
    	{
        	selected.remove(index);
    	}
    	
    }
    function setText(id)
    {
    	var textBox=document.getElementById("room_no");
    	var option=document.getElementById(id);
    	//window.alert(option.value);
    	textBox.value=option.value;
    }   
</script>
	</form>
	</html>
	


