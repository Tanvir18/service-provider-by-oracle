-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2017 at 09:45 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `service`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(11) NOT NULL,
  `host_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `message` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `host_id`, `user_id`, `from_date`, `to_date`, `status`, `message`) VALUES
(1, 12, 9, '2017-04-05', '2017-04-22', 1, 'hello'),
(4, 12, 9, '2017-04-23', '2017-04-25', 1, 'tf788i'),
(5, 12, 9, '2017-04-28', '2017-04-28', 1, 'r7'),
(6, 12, 9, '2017-04-29', '2017-04-30', 2, ''),
(7, 12, 9, '2017-05-01', '2017-05-01', 1, ''),
(8, 12, 9, '2017-05-03', '2017-05-09', 1, 'Hello'),
(9, 12, 12, '2017-05-02', '2017-05-02', 2, 'at 7 pm at uttara'),
(10, 14, 9, '2017-04-21', '2017-04-22', 0, 'dsdfsf'),
(11, 14, 14, '2017-04-19', '2017-04-19', 0, 'tr7uo'),
(12, 12, 9, '2017-05-10', '2017-05-10', 1, 'poiuytr'),
(13, 12, 9, '2017-07-08', '2017-07-08', 1, 'wedfui'),
(14, 13, 9, '2017-04-17', '2017-04-25', 2, 'jhj'),
(15, 13, 9, '2017-04-17', '2017-04-20', 1, ''),
(16, 13, 9, '2017-04-21', '2017-04-22', 2, 'ertyuol'),
(17, 13, 9, '2017-04-21', '2017-04-22', 2, 'jhgfd'),
(18, 13, 9, '2017-04-21', '2017-04-22', 0, ''),
(19, 12, 9, '2017-06-07', '2017-06-08', 1, 'wert'),
(20, 14, 13, '2017-04-20', '2017-04-20', 0, 'hi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
