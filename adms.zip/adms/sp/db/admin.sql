CREATE TABLE admin (
  id number(11) NOT NULL,
  username varchar2(25) NOT NULL,
  password varchar2(25) NOT NULL,
  role varchar2(10) NOT NULL
);


INSERT INTO admin (id, username, password, role) VALUES
(1, 'admin', 'admin', 'admin');
