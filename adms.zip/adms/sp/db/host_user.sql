-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2017 at 09:45 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `service`
--

-- --------------------------------------------------------

--
-- Table structure for table `host_user`
--

CREATE TABLE `host_user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `national_id` varchar(20) NOT NULL,
  `personal_information` varchar(255) NOT NULL,
  `skill` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL,
  `rate` varchar(10) NOT NULL,
  `photo` longblob NOT NULL,
  `category` varchar(55) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'free'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `host_user`
--

INSERT INTO `host_user` (`id`, `name`, `email`, `password`, `contact`, `address`, `national_id`, `personal_information`, `skill`, `experience`, `rate`, `photo`, `category`, `status`) VALUES
(1, 'qe24', '1992fac@gmail.com', '1', '2435678', 'asdfghjkl', '', '', '', '', '', '', '', 'free'),
(2, '124', '1992fac@gmail.com', '2', 'er', 'r', '', '', '', '', '', '', '', 'free'),
(3, 'sabit', 'fts@gmail.com', '2', '890', 'zxc', '', '', '', '', '', '', '', 'free'),
(4, 'saaq', 'admin@example.com', '1234', 'jfa;', 'kjjk', 'jkj', 'kjkj', 'kjkk', 'kjkj', 'kjkj', '', 'cook', 'free'),
(7, 'adnan', 'adnan@gmail.com', '1', '23456789', '3456tyghui', '123456789', 'jani na', 'kisu nai', 'jaina lav nai ', '200', 0x706572736f6e20636f6f6b2e6a7067, 'cook', 'booked'),
(11, 'gabriel', 'gab@gmail.com', '123456789', '01764691489', 'H#54, r#4, khilkhet', '43154786432597459', 'gabriel', 'mexican,italian', '2 years @ Le  Meridian', '500', 0x353142463337684768694c2e5f41435f554c3332305f53523238382c3332305f2e6a7067, 'cook', 'free'),
(12, 'lokkhon', 'lok@yahoo.com', '123456789', '01632145879', 'H#54, r#4, banani', '46587321587496532', 'lokkhon', 'Indian', '4 years @ sheraton', '450', 0x63713564616d2e7765625f2e70726573735f2e3732322e6b656570617370656374726174696f2d312d312d323430783330302e6a706567, 'cook', 'free'),
(13, 'sada', 'sada@gmail.com', '', '01555555669', 'H#54, r#4, dhanmondi', '43154786432597459', 'sada', 'wide angle', 'nil', '2000', 0x706572736f6e2070686f746f677261706865722e6a7067, 'photography', 'free'),
(14, 'imran', 'imran@gmail.com', '123456789', '01718549846', 'h#58, r#7', '459654985657235917', 'imran', 'electric circuit', '4 years', '100', 0x706572736f6e20656c65637472696369616e2e6a7067, 'electrician', 'free');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `host_user`
--
ALTER TABLE `host_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `host_user`
--
ALTER TABLE `host_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
