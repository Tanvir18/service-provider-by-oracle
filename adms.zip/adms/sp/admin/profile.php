

<?php include "includes/header.php"; ?>
    <div id="wrapper">

        <!-- Navigation -->
		
<?php include "includes/navigation.php";?>
<?php session_start(); ?>


<?php

if(isset($_SESSION["username"])){
	
	$username = $_SESSION["username"];
	
	$query = "SELECT * FROM users WHERE username = '{$username}' ";
	$query_result = mysqli_query($connection, $query);
	
	while($row = mysqli_fetch_assoc($query_result)){
		
		
	 $user_id  = $row["user_id"];
	 $username  = $row["username"];
	 $user_email  = $row["user_email"];
	 $user_password  = $row["user_password"];
	 $user_firstname  = $row["user_firstname"];
	 $user_lastname  = $row["user_lastname"];
	 $user_image  = $row["user_image"];
	 $user_role = $row["user_role"];
	
	}
	
}

 ?>


 
 
 <?php 

if(isset($_POST["update_user"])){
	
	$username = $_SESSION["username"];
	$update_username = $_POST["username"];
	$password = $_POST["password"];
	$email = $_POST["email"];
	$firstname = $_POST["firstname"];
	$lastname = $_POST["lastname"];
	$user_role = $_POST["user_role"];
	
	
	
	$query = "UPDATE users SET username='{$update_username}', user_password= '{$password}', user_email = '{$email}', user_firstname =  '{$firstname}', user_lastname = '{$lastname}', user_role = '{$user_role}' WHERE username = '{$username}' " ;
					
	$user_insert = mysqli_query($connection, $query);
	
	if(!$user_insert){
		die("query failed". mysqli_error($connection)); 
		
	}
	header("Location: user.php");
}

?>
		
		
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome to Admin
                            <small><?php echo $_SESSION["firstname"]; ?></small>
                        </h1>
				
						
<div class="col-md-6 col-md-offset-3">

<form action =" " method = "post" enctype="multipart/form-data">

	
	<div class = "form-group">
		<h3>Select Category</h3>
		<select name = "user_role" >
			<option value = "<?php echo $user_role; ?>"><?php echo $user_role; ?></option>
			
	<?php 
	
		if($user_role == "admin"){
			echo "<option value= 'subscriber'>subscriber</option>";
		}else{
			
			echo "<option value = 'admin'>admin</option>";
		}
	
	
	?>

		</select>
	</div>
	
	
	
	<div class = "form-group">
		<label for = "firstname">Firstname</label>
		<input type = "text" class = "form-control" name = "firstname" value = "<?php echo $user_firstname; ?>" />
	</div>
	
	
		<div class = "form-group">
		<label for = "lastname">Lastname</label>
		<input type = "text" class = "form-control" name = "lastname" value = "<?php echo $user_lastname; ?>"  />
	</div>
	
<!--	<div class = "form-group">
		<label for = "post_tags">Images</label>
		<input type = "file" name = "post_image" />
	</div>
	-->
	
		<div class = "form-group">
		<label for = "username">Username</label>
		<input type = "text" class = "form-control" name = "username" value = "<?php echo $username; ?>" />
	</div>
	
	<div class = "form-group">
		<label for = "email">Email</label>
		<input type = "email" class = "form-control" name = "email" value = "<?php echo $user_email; ?>" />
	</div>
	

	
	<div class = "form-group">
		<label for = "password">Password</label>
		<input type = "password" class = "form-control" name = "password" value = "<?php echo $user_password; ?>" />
	</div>
	
	
	
	
	<input type = "submit" class = "btn btn-primary btn-block btn-lg" name = "update_user" value = "Update" />
	
</form>
</div>


		
						
						
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- footer-->
	
	<?php include "includes/footer.php" ?>
    
