<?php include "includes/header.php";?>
    <div id="wrapper">



        <!-- Navigation -->
 
        <?php include "includes/navigation.php" ?>
        
   
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                       
                       
                        <h1 class="page-header">
                            Welcome to admin
                            
                            
                            <small> <?php 

                            //if(isset($_SESSION['username'])) {

                           // echo $_SESSION['username'];


                       // }





                            ?></small>
                        </h1>


     
                    </div>
                </div>
       
                <!-- /.row -->
                
       
                <div class="row">
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-file-text fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
               
			   <?php 
				
				$query = "SELECT * FROM user";
				$query_result = mysqli_query($connection, $query);
				$post_num = mysqli_num_rows($query_result);
				
				echo "<div class = 'huge'>{$post_num}</div>";
			   
			   ?>
			   
			   
                        <div>Signed User</div>
                    </div>
                </div>
            </div>
            <a href="post.php?source=view_pant">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-comments fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">

             <?php 
				
				$query = "SELECT * FROM host_user";
				$query_result = mysqli_query($connection, $query);
				$comment_num = mysqli_num_rows($query_result);
				
				echo "<div class = 'huge'>{$comment_num}</div>";
			   
			   ?>
                                      <div>Hosts</div>
                                    </div>
                                </div>
                            </div>
                            <a href="post.php?source=view_shirt">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-user fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">

                                        <?php /*
				
				$query = "SELECT * FROM products WHERE category = 'tshirt'";
				$query_result = mysqli_query($connection, $query);
				$user_num = mysqli_num_rows($query_result);
				
				echo "<div class = 'huge'>{$user_num}</div>";
			   */

                
			   ?>

                                       
                                        <div>Categories</div>
                                    </div>
                                </div>
                            </div>
                            <a href="post.php?source=view_t-shirt">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-list fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
  <?php 
				
				$query = "SELECT * FROM user";
				$query_result = mysqli_query($connection, $query);
				$category_num = mysqli_num_rows($query_result);
				
				echo "<div class = 'huge'>{$category_num}</div>";
			   
			   ?>
                                     

                                   <div> Users</div>
                                    </div>
                                </div>
                            </div>
                            <a href="user.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
     
	 
	 
	 
	 
	 <script type="text/javascript">
      google.load("visualization", "1.1", {packages:["bar"]});
      google.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
		['Data', 'number'],
		
		
		<?php 
		$comment_text = ['pants', 'shirts', 't-shirts', 'users'];
		$comment_count = [$post_num, $comment_num, $user_num, $category_num];
		
	  for($i = 0; $i<4; $i++){
		  
			echo "['{$comment_text[$i]}'" . "," . "{$comment_count[$i]}],";

 }
		
		?>
         
        ]);

        var options = {
          chart: {
            title: ' ',
            subtitle: ' ',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, options);
      }
    </script>
	 
	 <div id="columnchart_material" style="width: 'auto'; height: 500px;"></div>
                    
                </div>

  

            </div>
            <!-- /.container-fluid -->

        </div>
        
    
        <!-- /#page-wrapper -->
        
    <?php include "includes/footer.php" ?>
