

 <?php 

	if(isset($_POST["checkboxArray"])){
		
		foreach($_POST["checkboxArray"] as $checkBoxValue){
		
			$bulk_options = $_POST["bulk_options"];
			
			switch($bulk_options){
				
				
				case "delete";
				$query = "DELETE FROM products WHERE product_id = {$checkBoxValue}";
				$query_result = mysqli_query($connection, $query);
				break;
				
				
								 
				 while($row = mysqli_fetch_assoc($query_result)){
					 
					 $product_id  = $row["product_id"];
					 $category  = $row["category"];
					 $gender  = $row["gender"];
					 $image  = $row["image"];
					 
				 }
				 /*
				 $query = "INSERT INTO posts(post_title, category, post_author, post_status, post_tag, post_content, post_date, image) VALUES('{$post_title}', '{$category}',
								'{$post_author}', '{$post_status}', '{$post_tag}', '{$post_content}', now(), '{$image}') ";
				$post_insert = mysqli_query($connection, $query);
	
				if(!$post_insert){
					die("query failed". mysqli_error($connection)); 
					
				}*/
					break;
			}
			
			
	}	
	}
?>



<h3>All Posts</h3>

<h4>Multiple Delete</h4>
<form action = " " method= "post">

	<div id = "bulkOptionCounter">
		<div class = "form-group">
			<select class = "form-control" name = "bulk_options" >
				<option value = "">Select One</option>
				<option value = "delete">Delete</option>
			</select>
		</div>
		<input type = "submit" value = "Apply" class = "btn btn-success btn-md" name = "apply"/>
		<a href="post.php?source=add_post" class = "btn btn-primary btn-md">Add new</a>
	</div>
</br>
	<div class="table-responsive">
						<table class ="table table-bordered table-striped">
							<thead>
							<tr>
								<th><input type="checkbox" id = "checkBox"></th>
								<th>Category</th>
								<th>Gender</th>
								<th>Image</th>
								<!--<th>Edit</th>-->
								<th>Delete</th>
							</tr>
							</thead>
							<tbody>
							
 <?php 
 
 $query = "SELECT * FROM products ORDER BY product_id DESC";
 $post_result = mysqli_query($connection, $query);
 
 while($row = mysqli_fetch_assoc($post_result)){
	 
	 $product_id  = $row["product_id"];
	 $category  = $row["category"];
	 $gender  = $row["gender"];
	 $image  = $row["image"];
	
	 
	 
	  echo "<tr>";
	 ?>
			
	 <td><input type = 'checkbox' class = 'allCheckBox' name = 'checkboxArray[]' value ='<?php echo $product_id; ?>'/></td>
	
	 <?php

	// echo "<td>{$product_id}</td>";
	 echo "<td>{$category}</td>";
	 echo "<td>{$gender}</td>";
	//echo "<td>{$image}</td>";
	echo "<td><img  style='height:90px;width:105px;' src = '../img/{$image}'></td>";
	 
	
     //echo "<td><a class = 'btn btn-success' href='post.php?source=edit_post&p_id={$product_id}'>Edit</a></td>";
	 echo "<td><a class = 'btn btn-danger' onClick=\"javascript: return confirm('want to delete?'); \" href='post.php?delete={$product_id}'>Delete</a></td>";
	 
	 echo "</tr>";
 }
 
 if(isset($_GET["delete"])){
	 
	 $this_product_id = $_GET["delete"];
	 
	 $query = "DELETE FROM products WHERE product_id = $this_product_id";
	 
	 mysqli_query($connection, $query);
	 
	 header("location: post.php");
 }
 
 		
 ?>
 

						</tbody>
						</table>
						
			
						
						
						
					</form>
                      </div>
                    </div>