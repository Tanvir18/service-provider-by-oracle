<?php 

if(isset($_POST["update_user"])){
	
	$the_user_id = $_GET["p_id"];
	$username = $_POST["username"];
	$password = $_POST["password"];
	
	
	$query = "UPDATE admin SET username='{$username}', password= '{$password}' WHERE id = {$the_user_id}";
					
	$user_insert = mysqli_query($connection, $query);
	
	if(!$user_insert){
		die("query failed". mysqli_error($connection)); 
		
	}
	header("Location: user.php");
}

?>


<?php
	if(isset($_GET["p_id"])){
		
		$the_user_id = $_GET["p_id"];
	}
	
	
	$select_query = "SELECT * FROM admin WHERE id = {$the_user_id}" ;
	$select_query_result = mysqli_query($connection, $select_query);
	
	if(!$select_query_result){
		
		die("failed". mysqli_error($connection));
	}
	
	while($row = mysqli_fetch_assoc($select_query_result)){
		
		
		$username = $row["username"];
		$user_password = $row["password"];
		
		
		
	}
	
 ?>





<div class="col-md-6 col-md-offset-3">

<form action =" " method = "post" enctype="multipart/form-data">

	
	
	
	
	
		<div class = "form-group">
		<label for = "username">Username</label>
		<input type = "text" class = "form-control" name = "username" value = "<?php echo $username; ?>" />
	</div>
	
	
	<div class = "form-group">
		<label for = "password">Password</label>
		<input type = "password" class = "form-control" name = "password" value = "<?php echo $user_password; ?>" />
	</div>
	
	
	
	
	<input type = "submit" class = "btn btn-primary btn-block btn-lg" name = "update_user" value = "Update" />
	
</form>
</div>

