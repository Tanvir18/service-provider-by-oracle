<?php 

session_start();

  include('../a/config.php');

?>



<html><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://pingendo.github.io/pingendo-bootstrap/themes/default/bootstrap.css" rel="stylesheet" type="text/css">
  </head>
  <body>


      <script>
      $(document).ready(function(e){
        $("#Search").keyup(function(){
          $("#here").show();
          var x= $(this).val();
          $.ajax(
          {
              type:'GET',
              url:'fetch.php',
              data:'q='+x,
              success:function(data)
              {
                $("#here").html(data);
              }
          });
        });
      });
    
  </script>
  
  <style type="text/css">
    input
    {
      width: 400px;
      font-size: 24px;
    }
    #here
    {
      width: 400px;
      height: 300px;
      border: .5px solid grey;
      display: none;
    }

    #here a
    {
      display: block;
      width: 98%;
      padding: 1%;
      font-size: 20px;
      border-bottom: .5px solid grey;
    }
  </style>






    <div class="navbar navbar-default navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php"><span>Service Provider</span></a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-ex-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li class="">
              <a href="index.php">Home</a>
            </li>
             <li class="">
              <a href="logout.php"><?php if(isset($_SESSION['email'])){ echo "Sign Out ";} else echo "Sign In ";?><?php 
                if(isset($_SESSION['email'])) {
                  echo $_SESSION['email'];
                  
                  } 
              ?>

                
              </a>
            </li>
         
            
            <li class="">
              <a href="notification.php">Notification(
                 <?php
            $sql = "SELECT count(*) FROM booking WHERE host_id='$_SESSION[id]' and status=0";  
            $result =mysqli_query($con,$sql);
            $row=$result->fetch_array();
              echo $row[0];




            ?>
            )</a>
            </li>



          <?php if(isset($_SESSION['email'])){ echo '</li>
              <li class="">
                <a href="host_user_profile.php">Profile</a>
              </li> ';}
              ?>

                
              
            </li><li class="active">
              <a href="contract-us.php">Contact Us</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-offset-3 col-md-7">
            <form role="form">
              <div class="form-group">
                <div class="input-group">
                  <input type="Search" placeholder="Search Host name" name="Search" id="Search" size="80">
                  <div id="here"></div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="carousel slide" id="fullcarousel-example" data-interval="2000" data-ride="carousel">
      <div class="carousel-inner">
        <div class="item active">
          <img src="image\cook.jpg">
          <div class="carousel-caption">
            <h2>Cook</h2>
          </div>
        </div>
        <div class="item">
          <img src="image\electrician.jpg">
          <div class="carousel-caption">
            <h2>Elictricians</h2>
          </div>
        </div>
        <div class="item">
          <img src="image\interior design.jpg">
          <div class="carousel-caption">
            <h2>Interior Designer</h2>
          </div>
        </div>
        <div class="item">
          <img src="image\photographer.jpg">
          <div class="carousel-caption">
            <h2>Photographer</h2>
          </div>
        </div>
      </div>
    </div>
    <div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-2">
            <div class="btn-group btn-group-lg">
              <a class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Catagory<br><span class="fa fa-caret-down"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li>
            <a href="cook.php">Cook</a>
            <a href="Electrician.php">Electrician</a>
            <a href="Interior_designer.php">Interior Designer</a>
            <a href="Photographer.php">Photographer</a>
          </li>
              </ul>
            </div>
          </div>
          <div class="col-md-10">
            <div class="section">
              <div class="container">
                <div class="row">
                  <div class="col-md-3">
                    <img src="image\person cook.jpg" class="img-responsive">
                    <h2>
                      <a href="cook_profile.php">aaa</a>
                    </h2>
                    <p>Cook</p>
                  </div>
                  <a href="cook_profile.php">
                  </a>
                  <div class="col-md-3">
                    <a href="#">
                    <img src="image\person electrician.jpg" class="img-responsive">
                    </a>
                    <h2>
                      <a href="#">
                      </a>
                      <a href="#">bbb</a>
                    </h2>
                    <p>electrician</p>
                  </div>
                  <div class="col-md-3">
                    <img src="image\person photographer.jpg" class="img-responsive">
                    <h2>
                      <a href="#">ccc</a>
                    </h2>
                  </div>
                </div>
                <a href="#">
              </a>
              </div>
              <a href="#">
            </a>
            </div>
            <a href="#">
          </a>
          </div>
          <a href="#">
        </a>
        </div>
        <a href="#">
      </a>
      </div>
      <a href="#">
    </a>
    </div>
    <a href="#">
    </a>
    <footer class="section section-primary">
      <a href="#">
      </a>
      <div class="container">
        <div class="row">
          <div class="col-sm-6">
            <h1>Service Provider</h1>
            <p>service Provider is an e-commerce web site where you can hire man power
              according to your needs who are willingly to work for you.</p>
          </div>
          <div class="col-sm-6">
            <a href="#">
            <p class="text-info text-right">
              <br>
              <br>
            </p>
            </a>
            <div class="row">
              <a href="#">
              </a>
              <div class="col-md-12 hidden-lg hidden-md hidden-sm text-left">
                <a href="#">
                </a>
                <a href="#"><i class="fa fa-3x fa-fw fa-instagram text-inverse"></i></a>
                <a href="#"><i class="fa fa-3x fa-fw fa-twitter text-inverse"></i></a>
                <a href="#"><i class="fa fa-3x fa-fw fa-facebook text-inverse"></i></a>
                <a href="#"><i class="fa fa-3x fa-fw fa-github text-inverse"></i></a>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 hidden-xs text-right">
                <a href="#"><i class="fa fa-3x fa-fw fa-instagram text-inverse"></i></a>
                <a href="#"><i class="fa fa-3x fa-fw fa-twitter text-inverse"></i></a>
                <a href="https://www.facebook.com/tanvir.ahmed.545"><i class="fa fa-3x fa-fw fa-facebook text-inverse"></i></a>
                <a href="#"><i class="fa fa-3x fa-fw fa-github text-inverse"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  

</body></html>