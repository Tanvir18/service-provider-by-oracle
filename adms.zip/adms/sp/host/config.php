<?php
$servername = 'localhost';
$username   = 'root';
$password   = '';
$dbname     = 'service';
$con = mysqli_connect($servername,$username,$password,$dbname);
?>