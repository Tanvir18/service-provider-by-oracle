<?php
	session_start();
  include('config.php');

?>

<html><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://pingendo.github.io/pingendo-bootstrap/themes/default/bootstrap.css" rel="stylesheet" type="text/css">
  </head><body>
    <div class="navbar navbar-default navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php"><span>Service Provider</span></a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-ex-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li class="">
              <a href="index.php">Home</a>
            </li>
            <li class="">
              <a href="logout.php">Sign out <?php echo $_SESSION['email']; ?></a>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Sign up <i class="fa fa-caret-down"></i></a>
              <ul class="dropdown-menu" role="menu">
                <li id="signup">
                  <a href="Signup.php">as User</a>
                </li>
                <li>
                  <a href="host_sign.php">as Host</a>
                </li>

                
              </ul>
            </li>
            <li class="">
              <a href="notification.php">Notification</a>
            </li>


            </li>
             <?php if(isset($_SESSION['email'])){ echo '</li>
              <li class="">
                <a href="host_user_profile.php">Profile</a>
              </li> ';}
              ?>


            <li class="active">
              <a href="contract-us.php">Contact Us</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-4">


<?php 
if(isset($_SESSION['id'])){
  
    $get_pid = $_SESSION['id'];
    
}

if (!empty($get_pid)) {


 $query = "SELECT * FROM host_user WHERE id = $get_pid";
 $query_result = odbc_exec($con, $query);
 

   
 while($row = odbc_fetch_array($query_result)){

       $id = $row['id']; 
       $name=$row['name'];
       $email=$row['email'];
       $contact=$row['contact'];
       $address=$row['address'];
       $national_id  =  $row['national_id'];
       $personal_information  =  $row['personal_information'];
       $skill  =  $row['skill'];
       $experience  =$row['experience'];
       $rate  =$row['rate'];
       $fileToUpload  = $row['photo'];
       
       $category  =  $row['category']; 
       $status  = $row['status'];
       
 }?>




            <img src="image\person cook.jpg" class="img-responsive">
          </div>
          <div class="col-md-6">
            <h1><?php echo $name; ?></h1>
            <p></p><h2>
            Personal Information<br><br>Name: <?php echo $name; ?><br><br>
            Email: <?php echo $email; ?><br><br>
            National ID:<?php echo $national_id; ?><br><br>
            Skill:<?php echo $skill; ?><br><br><br>
            Experience:<?php echo $experience; ?><br><br>
            Rate:<?php echo $rate; ?>tk per hr<br><br>
            Contact Information:<?php echo $contact; ?><br><br>
            Status:<?php echo $status; ?><br><br>

            

<?php } ?>

          </div>

          <div class="col-md-2">
<?php 
               if (!empty($get_pid)) {
               echo "<a class='btn btn-primary btn-md' href='edit_host_profile.php?user_id={$id}'>Edit Profile</a>";
               }?>


         </div>
        </div>
      </div>
    </div>

    
<?php
  include('../a/footer.php');
?>
  

</body></html>