<?php 
	include('../a/header.php'); 
	include('../a/config.php');

	if(isset($_POST['submit'])){
		$pass1=$_POST['password'];
		$pass2=$_POST['confirm_password'];
		$email=$_POST['email'];
		$contact=$_POST['contact'];
		$national_id=$_POST['national_id'];
		$skill=$_POST['skill'];
		$experience=$_POST['experience'];
		$rate=$_POST['rate'];
		if($pass1!=$pass2){
			echo "Password did not match!";
		}else{
			$sql = "UPDATE host_user set email='$email',contact='$contact',national_id='$national_id',password='$pass1',skill='$skill',experience='$experience',rate='$rate' WHERE id='$_SESSION[id]'";  
		    $result =mysqli_query($con,$sql);
		    echo "Updated successfully!";
		    header('location:../host/host_user_profile.php');

		}
	}
	$sql = "SELECT * FROM host_user WHERE id='$_SESSION[id]'";  
	
    $result =mysqli_query($con,$sql);
    $cur=$result->fetch_assoc();
            

 
?>





<body>
<div class="container">
     <div class="row ">
	    <div class="col-md-offset-4 col-sm-offset-4  ">
		    <h2>Update Profile</h2>
		   <form action="" method="POST">
		       <table>
			      
				  
				   <tr>
				     <td>Email</td>
					  <td><input type="text" name="email" value="<?php echo $_SESSION['email']; ?>"></td>
				  </tr>
				   <tr>
				     <td>Password</td>
					  <td><input type="password" name="password"></td>
				  </tr>
				   <tr>
				     <td>Confirm Password</td>
					  <td><input type="password" name="confirm_password"></td>
				  </tr>

				  <tr>
				     <td>National ID</td>
					  <td><input type="text" name="national_id" value="<?php echo $cur['national_id']; ?>"></td>
				  </tr>
				  <tr>
				     <td>Skill</td>
					  <td><input type="text" name="skill" value="<?php echo $cur['skill']; ?>"></td>
				  </tr>
				  <tr>
				     <td>Experience</td>
					  <td><input type="text" name="experience" value="<?php echo $cur['experience']; ?>"></td>
				  </tr>
				  <tr>
				     <td>Rate</td>
					  <td><input type="text" name="rate" value="<?php echo $cur['rate']; ?>"></td>
				  </tr>

				   <tr>
				     <td>Contact</td>
					  <td><input type="text" name="contact" value="<?php echo $cur['contact']; ?>"></td>
				  </tr>
				   
				 
				 
				  
				 
				  
				 
		       </table>
		       <input type="submit" value="Update" name="submit" >
					<a href="user_profile.php"> Cancel</a>
            </form>
		</div>
	 </div>
  </div>

  
<?php
  include('../a/footer.php');
?>
</body>
